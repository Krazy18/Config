"""
: player vs enemy bot.
- Player dikontrol keyboard (WASD)
- Enemy bot: state machine (idle, chase, attack, retreat)
- terhubung ke Mobile Legends.
"""

import pygame
import math
import random
import sys
from enum import Enum, auto

# ---------- konfigurasi ----------
WIDTH, HEIGHT = 900, 600
FPS = 60

PLAYER_SPEED = 220       # px per detik
ENEMY_SPEED = 160
ATTACK_RANGE = 60
SAFE_DISTANCE = 200
ATTACK_COOLDOWN = 1.0    # detik
SKILL_COOLDOWN = 5.0
SKILL_RANGE = 200
PLAYER_MAX_HP = 100
ENEMY_MAX_HP = 100

# ---------- inisialisasi pygame ----------
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 24)

# ---------- helper ----------
def clamp(v, a, b):
    return max(a, min(b, v))

def distance(a, b):
    return math.hypot(a[0]-b[0], a[1]-b[1])

def normalize(vx, vy):
    mag = math.hypot(vx, vy)
    if mag == 0:
        return 0, 0
    return vx/mag, vy/mag

# ---------- state machine untuk bot ----------
class EnemyState(Enum):
    IDLE = auto()
    CHASE = auto()
    ATTACK = auto()
    RETREAT = auto()
    USE_SKILL = auto()

# ---------- entity ----------
class Entity:
    def __init__(self, x, y, color, radius=18, max_hp=100):
        self.x = x
        self.y = y
        self.color = color
        self.radius = radius
        self.max_hp = max_hp
        self.hp = max_hp

    def pos(self):
        return (self.x, self.y)

    def draw(self, surf):
        pygame.draw.circle(surf, self.color, (int(self.x), int(self.y)), self.radius)
        # draw HP bar
        w = 40
        h = 6
        hx = int(self.x - w//2)
        hy = int(self.y - self.radius - 12)
        frac = clamp(self.hp / self.max_hp, 0, 1)
        pygame.draw.rect(surf, (80,80,80), (hx, hy, w, h))
        pygame.draw.rect(surf, (50,200,50), (hx, hy, int(w*frac), h))

# ---------- player ----------
class Player(Entity):
    def __init__(self, x, y):
        super().__init__(x, y, (50,120,255), radius=18, max_hp=PLAYER_MAX_HP)
        self.speed = PLAYER_SPEED
        self.attack_damage = 12

    def update(self, dt, keys):
        vx = 0
        vy = 0
        if keys[pygame.K_w]:
            vy -= 1
        if keys[pygame.K_s]:
            vy += 1
        if keys[pygame.K_a]:
            vx -= 1
        if keys[pygame.K_d]:
            vx += 1
        nx, ny = normalize(vx, vy)
        self.x += nx * self.speed * dt
        self.y += ny * self.speed * dt
        self.x = clamp(self.x, 20, WIDTH-20)
        self.y = clamp(self.y, 20, HEIGHT-20)

# ---------- enemy bot ----------
class EnemyBot(Entity):
    def __init__(self, x, y):
        super().__init__(x, y, (220,80,80), radius=20, max_hp=ENEMY_MAX_HP)
        self.state = EnemyState.IDLE
        self.speed = ENEMY_SPEED
        self.attack_damage = 10
        self.attack_cooldown = 0.0
        self.skill_cooldown = 0.0

    def update(self, dt, player):
        # cooldowns
        self.attack_cooldown = max(0.0, self.attack_cooldown - dt)
        self.skill_cooldown = max(0.0, self.skill_cooldown - dt)

        dist = distance(self.pos(), player.pos())

        # state transitions
        if self.state == EnemyState.IDLE:
            # random wander or switch to chase if player is near
            if dist < 300:
                self.state = EnemyState.CHASE
            else:
                # small wandering
                if random.random() < 0.01:
                    self.wander_target = (random.uniform(50, WIDTH-50), random.uniform(50, HEIGHT-50))
                if hasattr(self, 'wander_target'):
                    tx, ty = self.wander_target
                    if distance(self.pos(), (tx,ty)) < 10:
                        del self.wander_target

        elif self.state == EnemyState.CHASE:
            if dist <= ATTACK_RANGE:
                self.state = EnemyState.ATTACK
            elif dist > 450:
                self.state = EnemyState.IDLE
            elif dist < SAFE_DISTANCE and self.hp < self.max_hp * 0.35:
                # low hp and too close -> retreat
                self.state = EnemyState.RETREAT
            elif self.skill_cooldown <= 0 and dist <= SKILL_RANGE:
                self.state = EnemyState.USE_SKILL

        elif self.state == EnemyState.ATTACK:
            if dist > ATTACK_RANGE + 10:
                self.state = EnemyState.CHASE
            elif self.hp < self.max_hp * 0.25:
                self.state = EnemyState.RETREAT

        elif self.state == EnemyState.RETREAT:
            if dist > SAFE_DISTANCE + 20:
                self.state = EnemyState.IDLE
            elif self.hp >= self.max_hp * 0.6:
                self.state = EnemyState.CHASE

        elif self.state == EnemyState.USE_SKILL:
            # after using skill, go back to chase
            self.state = EnemyState.CHASE

        # actions based on state
        if self.state == EnemyState.IDLE:
            if hasattr(self, 'wander_target'):
                tx, ty = self.wander_target
                self.move_towards(tx, ty, dt)
        elif self.state == EnemyState.CHASE:
            self.move_towards(player.x, player.y, dt)
        elif self.state == EnemyState.ATTACK:
            # attempt attack if cooldown ready
            if self.attack_cooldown <= 0:
                self.attack(player)
                self.attack_cooldown = ATTACK_COOLDOWN
        elif self.state == EnemyState.RETREAT:
            # move away from player
            dx = self.x - player.x
            dy = self.y - player.y
            nx, ny = normalize(dx, dy)
            self.x += nx * self.speed * dt
            self.y += ny * self.speed * dt
            self.x = clamp(self.x, 20, WIDTH-20)
            self.y = clamp(self.y, 20, HEIGHT-20)
        elif self.state == EnemyState.USE_SKILL:
            # example: dash + damage
            if self.skill_cooldown <= 0:
                self.use_skill(player)
                self.skill_cooldown = SKILL_COOLDOWN

    def move_towards(self, tx, ty, dt):
        dx = tx - self.x
        dy = ty - self.y
        nx, ny = normalize(dx, dy)
        self.x += nx * self.speed * dt
        self.y += ny * self.speed * dt
        self.x = clamp(self.x, 20, WIDTH-20)
        self.y = clamp(self.y, 20, HEIGHT-20)

    def attack(self, player):
        # simple hit if in range
        if distance(self.pos(), player.pos()) <= ATTACK_RANGE + 4:
            player.hp = clamp(player.hp - self.attack_damage, 0, player.max_hp)
            # small knockback
            dx = player.x - self.x
            dy = player.y - self.y
            nx, ny = normalize(dx, dy)
            player.x += nx * 8
            player.y += ny * 8

    def use_skill(self, player):
        # dash towards player and deal area damage
        dx = player.x - self.x
        dy = player.y - self.y
        nx, ny = normalize(dx, dy)
        dash_dist = 80
        self.x += nx * dash_dist
        self.y += ny * dash_dist
        # damage if close enough
        if distance(self.pos(), player.pos()) <= 90:
            player.hp = clamp(player.hp - 25, 0, player.max_hp)

# ---------- game loop ----------
def draw_text(surf, text, x, y, color=(255,255,255)):
    img = font.render(text, True, color)
    surf.blit(img, (x, y))

def main():
    player = Player(WIDTH*0.25, HEIGHT*0.5)
    enemy = EnemyBot(WIDTH*0.75, HEIGHT*0.5)
    running = True
    elapsed = 0.0

    while running:
        dt = clock.tick(FPS) / 1000.0
        elapsed += dt

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()
        player.update(dt, keys)
        enemy.update(dt, player)

        # simple player attack: space = basic attack
        if keys[pygame.K_SPACE]:
            if distance(player.pos(), enemy.pos()) <= ATTACK_RANGE + 6:
                enemy.hp = clamp(enemy.hp - player.attack_damage, 0, enemy.max_hp)

        # draw
        screen.fill((18,18,30))
        # draw safe circle for enemy behavior (for debugging/visualization)
        pygame.draw.circle(screen, (120,120,120), (int(enemy.x), int(enemy.y)), SAFE_DISTANCE, 1)
        pygame.draw.circle(screen, (80,80,80), (int(enemy.x), int(enemy.y)), SKILL_RANGE, 1)
        player.draw(screen)
        enemy.draw(screen)

        # HUD
        draw_text(screen, f"Player HP: {int(player.hp)} / {player.max_hp}", 10, 10)
        draw_text(screen, f"Enemy HP: {int(enemy.hp)} / {enemy.max_hp}", 10, 34)
        draw_text(screen, f"Enemy State: {enemy.state.name}", 10, 58)
        draw_text(screen, "Controls: WASD move | SPACE attack", 10, HEIGHT-30)

        # win/lose
        if player.hp <= 0:
            draw_text(screen, "YOU DIED - Press R to restart", WIDTH//2 - 120, HEIGHT//2, (255,50,50))
        if enemy.hp <= 0:
            draw_text(screen, "ENEMY DOWN - Press R to restart", WIDTH//2 - 140, HEIGHT//2 - 30, (50,255,80))

        # restart
        if keys[pygame.K_r]:
            player = Player(WIDTH*0.25, HEIGHT*0.5)
            enemy = EnemyBot(WIDTH*0.75, HEIGHT*0.5)

        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
"expired date -03-11-2025"
"SCRIPT BY MAS IKKY OFFICIAL"